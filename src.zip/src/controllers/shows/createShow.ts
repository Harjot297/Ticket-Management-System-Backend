import express from 'express';
import mongoose from 'mongoose';
import Movie from '../../schemas/Movie';
import Theatre from '../../schemas/Theatre';
import Hall from '../../schemas/Hall';
import Show from '../../schemas/Show';

export const createShow = async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    const {
      movieId,
      theatreId,
      hallId,
      showDate,       // format: YYYY-MM-DD
      startTime,      // format: HH:mm
      endTime,        // format: HH:mm
      language,
      format,
      pricing,
    } = req.body;

    // Basic field checks
    if (!movieId || !theatreId || !hallId || !startTime || !endTime || !language || !format || !showDate) {
      res.status(400).json({
        success: false,
        message: 'Please provide all the required fields',
      });
      return;
    }

    if (!pricing || !pricing.regular || !pricing.vip || !pricing.premium) {
      res.status(400).json({
        success: false,
        message: 'Please provide pricing for all the categories',
      });
      return;
    }

    if (
      !mongoose.Types.ObjectId.isValid(movieId) ||
      !mongoose.Types.ObjectId.isValid(theatreId) ||
      !mongoose.Types.ObjectId.isValid(hallId)
    ) {
      res.status(400).json({
        success: false,
        message: 'Invalid movieId, theatreId or hallId',
      });
      return;
    }

    // Validate showDate
    if (!/^\d{4}-\d{2}-\d{2}$/.test(showDate)) {
      res.status(400).json({
        success: false,
        message: 'Invalid showDate format. Use YYYY-MM-DD',
      });
      return;
    }

    // Construct full Date objects for start and end time
    const start = new Date(`${showDate}T${startTime}:00+05:30`);
    const end = new Date(`${showDate}T${endTime}:00+05:30`);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      res.status(400).json({
        success: false,
        message: 'Invalid startTime or endTime format. Use HH:mm',
      });
      return;
    }

    if (end <= start) {
      res.status(400).json({
        success: false,
        message: 'endTime must be after startTime',
      });
      return;
    }

    // Fetch theatre and ownership check
    const theatre = await Theatre.findById(theatreId);
    if (!theatre) {
      res.status(404).json({ success: false, message: 'Theatre not found' });
      return;
    }

    if (req.user.role !== 'admin' && req.user.userId.toString() !== theatre.owner.toString()) {
      res.status(403).json({
        success: false,
        message: 'You are not authorized to create a show for this theatre',
      });
      return;
    }

    // Fetch movie
    const movie = await Movie.findById(movieId);
    if (!movie) {
      res.status(404).json({ success: false, message: 'Movie not found' });
      return;
    }

    const movieRuntime = movie.duration; // in minutes
    const showDuration = (end.getTime() - start.getTime()) / (1000 * 60); // in minutes

    if (movieRuntime > showDuration) {
      res.status(400).json({
        success: false,
        message: 'Movie runtime is greater than the show duration',
      });
      return;
    }

    // Fetch hall
    const hall = await Hall.findById(hallId);
    if (!hall) {
      res.status(404).json({ success: false, message: 'Hall not found' });
      return;
    }

    if (hall.theatreId.toString() !== theatreId) {
      res.status(400).json({
        success: false,
        message: 'Hall does not belong to the theatre',
      });
      return;
    }

    // Check for overlapping shows in same hall
    const overlappingShow = await Show.findOne({
      hallId: hallId,
      $or: [
        {
          startTime: { $lt: end },
          endTime: { $gt: start },
        },
      ],
    });

    if (overlappingShow) {
      res.status(400).json({
        success: false,
        message: 'Show cannot be created due to overlap with an existing show',
      });
      return;
    }

    // Create show
    const show = await Show.create({
      movieId,
      hallId,
      theatreId,
      showDate: new Date(showDate),
      startTime: start,
      endTime: end,
      language: movie.language,
      format: hall.format,
      seatsBooked: [],
      status: 'scheduled',
      pricing,
    });

    res.status(200).json({
      success: true,
      message: 'Show created successfully',
      data: show,
    });
  } catch (err) {
    console.error('Error creating show:', err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
    });
  }
};
