export default  interface RejectTheatre {
  theatreId: string;
  reason: string;
}
