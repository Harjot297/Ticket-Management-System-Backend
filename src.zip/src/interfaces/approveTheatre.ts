export default interface ApproveTheatreBody {
  theatreId: string;
}
