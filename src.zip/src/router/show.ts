import express from 'express'
import { createShow } from '../controllers/shows/createShow'
import { auth } from '../middlewares/auth'
import { isTheatreOrAdmin } from '../middlewares/isTheatreOrAdmin'

export default(router: express.Router) => {
    router.post('/show/create' , auth , isTheatreOrAdmin , createShow);
}